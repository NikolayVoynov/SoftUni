package solutions;

public class CookiesProblem {
    public Integer solve(int k, int[] cookies) {
        return null;
    }
}
