package solutions;

import java.util.List;

public class BinaryTree {

    public BinaryTree(int key, BinaryTree first, BinaryTree second) {

    }

    public Integer findLowestCommonAncestor(int first, int second) {
        return null;
    }

    public List<Integer> topView() {
        return null;
    }
}
